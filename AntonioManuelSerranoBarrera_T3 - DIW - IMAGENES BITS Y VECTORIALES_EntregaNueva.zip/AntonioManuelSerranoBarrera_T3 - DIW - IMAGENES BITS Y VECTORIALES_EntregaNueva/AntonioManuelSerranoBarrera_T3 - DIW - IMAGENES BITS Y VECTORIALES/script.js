// Variables 

selectorA = document.getElementById('selector-imagenes');
selectorB = document.getElementById('selector-charts');

selectorAopcion = null;
selectorBopcion = null;

let donutChart = null;
let barChart = null;

const tabla = document.getElementById('tablaImagenes');

// JSON de datos

const datosA = {
    "SWY Intensly": 15,
    "Dior Sauvage": 30,
    "Acqua di Gio": 40,
    "Black Opium": 20
}
const datosB = {
    "MontBlanc Starwalker": 25,
    "Sport Man": 12,
    "Eau d'Kincillo": 8,
    "Invictus Elixir": 30
};

// Arrays que sacan os datos de los JSON

const marcasA = Object.keys(datosA);
const numerosA = Object.values(datosA);

const marcasB = Object.keys(datosB);
const numerosB = Object.values(datosB);

// Evento que escucha el selector de las imagenes, coge su valor y dependiendo de este crea imagenes segun el numero y el for

selectorA.addEventListener("change", function () {
    selectorAopcion = document.getElementById('selector-imagenes').value;
    tabla.innerHTML = "";
    for (let i = 0; i <= selectorAopcion; i++) {
        tabla.innerHTML += `
            <tr>
                <td><img class="rounded-circle" src="https://picsum.photos/100/100?random=${i}" loading="lazy"></td> 
                <td>Descripcion${i}</td>
                <td>${Date.now() + i}</td>
            </tr>
        `;
    }

});

// Evento que escucha el selector de los datos de chart, coge su valor y muestra el donut y el charBar de un tipo de valor u otro

selectorB.addEventListener("change", function () {
    selectorBopcion = document.getElementById('selector-charts').value;
    console.log(selectorBopcion)

    //Lineas para que no se pete y se sobreescriban al cambiar los datos 
    if (donutChart) donutChart.destroy();
    if (barChart) barChart.destroy();
    document.querySelector("#chart-donut").innerHTML = ""
    document.querySelector("#chart-normal").innerHTML = ""

    if (selectorBopcion == "A") {

        //Donut tipo A con JSON de datos A
        var options1 = {
            series: numerosA,
            labels: marcasA,
            chart: {
                type: 'donut',
            },
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };

        donutChart = new ApexCharts(document.querySelector("#chart-donut"), options1);
        donutChart.render();

        //charBar tipo A con JSON de datos A
        var options2 = {
            series: [{
                data: numerosA
            }],
            chart: {
                height: 350,
                type: 'bar',
                events: {
                    click: function (chart, w, e) {
                    }
                }
            },

            dataLabels: {
                enabled: false
            },
            legend: {
                show: false
            },
            xaxis: {
                categories: marcasA,
                labels: {
                }
            }
        };

        barChart = new ApexCharts(document.querySelector("#chart-normal"), options2);
        barChart.render();

    }

    //Donut tipo B con JSON de datos B
    if (selectorBopcion == "B") {

        var options3 = {
            series: numerosB,
            labels: marcasB,
            chart: {
                type: 'donut',
            },
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };

        donutChart = new ApexCharts(document.querySelector("#chart-donut"), options3);
        donutChart.render();

        //charBar tipo B con JSON de datos B
        var options4 = {
            series: [{
                data: numerosB
            }],
            chart: {
                height: 350,
                type: 'bar',
                events: {
                    click: function (chart, w, e) {
                    }
                }
            },

            dataLabels: {
                enabled: false
            },
            legend: {
                show: false
            },
            xaxis: {
                categories: marcasB,
                labels: {
                }
            }
        };

        barChart = new ApexCharts(document.querySelector("#chart-normal"), options4);
        barChart.render();


    }

});